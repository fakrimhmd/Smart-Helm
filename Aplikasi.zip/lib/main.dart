import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gpsapps/features/home/data/home_remote_data_source.dart';
import 'package:gpsapps/features/home/data/home_remote_firebase_notification.dart';
import 'package:gpsapps/features/home/presentation/cubit/home_realtime_cubit.dart';
import 'package:provider/provider.dart';

import 'core/routes/routes.dart';
import 'core/theme/theme.dart';
import 'features/home/presentation/provider/home_realtime_bool.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    // options: FirebaseOptions(
    //     apiKey: "AIzaSyDf98jaRhYwyHKRuspox-1NKHQCf2CnfxY",
    //     appId: "1:355547706938:web:a03af9e2b77c3a9490a703",
    //     messagingSenderId: "355547706938",
    //     projectId: "gps-apps-41932"),
  );
  await FirebaseApi().initNotifications();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HomeRealtimeProvider()),
      ],
      child: const MyApp()),
    // ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => HomeRealtimeCubit()),

        // ], child: MaterialApp(
      ], child: MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      themeMode: ThemeMode.system,
      theme: GTheme.lightTheme,
      routerConfig: AppRouter.router,
    // ),
    ),
    );

  }
}
