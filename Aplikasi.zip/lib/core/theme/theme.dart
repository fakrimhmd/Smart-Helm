import 'package:flutter/material.dart';
import 'package:gpsapps/core/theme/text_theme.dart';

class GTheme {
  GTheme._();

  static ThemeData lightTheme = ThemeData(
    dialogTheme: DialogTheme(backgroundColor: Colors.white),
    useMaterial3: true,
    fontFamily: 'Poppins',
    brightness: Brightness.light,
    primaryColor: Colors.white,
    scaffoldBackgroundColor: Colors.white,
    textTheme: GTextTheme.lightTextTheme,
    colorScheme: ColorScheme.fromSeed(seedColor: Colors.purple,
      // primary: Colors.blue
    ),

  );
}