import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:gpsapps/features/home/presentation/screen/detak_jantung_screen.dart';
import 'package:gpsapps/features/home/presentation/screen/home_screen.dart';
import 'package:gpsapps/features/home/presentation/screen/kontrol_screen.dart';
import 'package:gpsapps/features/home/presentation/screen/location_screen.dart';

import '../errors/routes_error.dart';
import 'constants.dart';


class AppRouter {

  static final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');
  // static final GlobalKey<NavigatorState> _shellNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'shell');

  static final GoRouter _router = GoRouter(
    initialLocation: Routes.homeScreenRootNamedPage,
    debugLogDiagnostics: true,
    navigatorKey: _rootNavigatorKey,
    routes: [

      GoRoute(
          path: Routes.homeScreenRootNamedPage,
          builder: (BuildContext context, GoRouterState state) =>  HomeScreen()
      ),

      GoRoute(
          path: Routes.locationNamedPage,
          builder: (BuildContext context, GoRouterState state) => LocationScreen()
      ),

      GoRoute(
          path: Routes.heartRateNamedPage,
          builder: (BuildContext context, GoRouterState state) => DetakJantungScreen()
      ),

      GoRoute(
          path: Routes.controlNamedPage,
          builder: (BuildContext context, GoRouterState state) => KontrolScreen()
      ),
    ],
    errorBuilder: (context, state) => const NotFoundScreen(),

  );

  static GoRouter get router => _router;
}

