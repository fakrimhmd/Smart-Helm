part of 'home_realtime_cubit.dart';

abstract class HomeRealtimeState extends Equatable {
  const HomeRealtimeState();

  @override
  List<Object> get props => [];
}

class HomeRealtimeInitial extends HomeRealtimeState {}

class HomeRealtimeLoading extends HomeRealtimeState {}


class LocationRealtimeSuccess extends HomeRealtimeState {
  final List<HomeModel> homeReal;

  LocationRealtimeSuccess(this.homeReal);

  @override
  List<Object> get props => [homeReal];
}

class MonitoringRealtimeSuccess extends HomeRealtimeState {
  final Map<String, List<MonitoringModel>> monitoringReal;

  MonitoringRealtimeSuccess(this.monitoringReal);

  @override
  List<Object> get props => [monitoringReal];
}

class ControlRealtimeSuccess extends HomeRealtimeState {
  final Map<String, List<ControlModel>> controlReal;

  ControlRealtimeSuccess(this.controlReal);

  @override
  List<Object> get props => [controlReal];
}

class HomeRealtimeFailed extends HomeRealtimeState {
  final String error;

  HomeRealtimeFailed(this.error);

  @override
  List<Object> get props => [error];
}