import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:gpsapps/features/home/model/home_model.dart';

import '../../data/home_remote_data_source.dart';

part 'home_realtime_state.dart';

class HomeRealtimeCubit extends Cubit<HomeRealtimeState> {
  HomeRealtimeCubit() : super(HomeRealtimeInitial());

  void fetchLocationRealtime() async {
    try {
      emit(HomeRealtimeLoading());

      List<HomeModel> locationReal =
      await HomeService().fetchRealtime();

      emit(LocationRealtimeSuccess(locationReal));
    } catch (e) {
      emit(HomeRealtimeFailed(e.toString()));
    }
  }
  void fetchControlRealtime() {
    emit(HomeRealtimeLoading());
    HomeService().fetchControlRealtime().listen(
          (controlData) {
        emit(ControlRealtimeSuccess({
          'sistem-state': controlData,
        }));
      },
      onError: (e) {
        emit(HomeRealtimeFailed(e.toString())
        );
      },
    );
  }

  void fetchMonitoringRealtime() async {
    emit(HomeRealtimeLoading());
    HomeService().fetchMonitoringRealtime().listen(
            (monitorData) {
              emit(MonitoringRealtimeSuccess({
                'detak-jantung': monitorData,
              }));
            },
      onError: (e) {
        emit(HomeRealtimeFailed(e.toString())
        );
      },
    );
  }

  Future<void> updateSistemState(bool sistemState) async {
    try {
      await HomeService().updateRealtime(
          data: {'sistem-state': sistemState
          });
    } catch (error) {
      emit(HomeRealtimeFailed('Failed to update state-mode : $error'));
    }
  }
}
