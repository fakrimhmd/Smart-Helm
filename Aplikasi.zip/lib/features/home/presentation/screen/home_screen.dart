import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gpsapps/core/constants/colors.dart';
import 'package:gpsapps/core/helper/helper_functions.dart';
import 'package:gpsapps/core/routes/constants.dart';
import 'package:gpsapps/core/routes/routes.dart';
import 'package:gpsapps/features/home/presentation/cubit/home_realtime_cubit.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:provider/provider.dart';

import '../provider/home_realtime_bool.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    double latitude = 0.0;
    double longitude = 0.0;
    bool isMaps = false;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: GColors.secondary,
        appBar: AppBar(
          title: Text("Home Screen",
          style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          backgroundColor: GColors.primary,
          // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 21, vertical: 21),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      AppRouter.router.go(Routes.heartRateNamedPage);
                    },
                    child: Container(
                      height: GHelperFunctions.screenHeight(context) * 0.25,
                      width: GHelperFunctions.screenWidth(context) * 0.4,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
                      color:GColors.white,),
                      child: Column(
                        children: [
                        Image.asset("assets/images/heart_rate_icon.png",
                        height: 100,
                        width: 100,
                        ),
                          SizedBox(height: 15),

                          Text("Detak Jantung")
                      ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      AppRouter.router.go(Routes.locationNamedPage);
                    },
                    child: Container(
                      height: GHelperFunctions.screenHeight(context) * 0.25,
                      width: GHelperFunctions.screenWidth(context) * 0.4,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
                          color:GColors.white),
                      child: Column(children: [
                        Image.asset("assets/images/maps_icon_2.png",
                          height: 100,
                          width: 100,
                          color: GColors.primary,
                        ),
                        SizedBox(height: 15),
                        Text("Lokasi")
                      ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15),
              GestureDetector(
                onTap: () {
                  AppRouter.router.go(Routes.controlNamedPage);
                },
                child: Container(
                  height: GHelperFunctions.screenHeight(context) * 0.25,
                  width: GHelperFunctions.screenWidth(context) * 0.4,
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
                      color:GColors.white),
                  child: Column(children: [
                    Image.asset("assets/images/control_icon.png",
                      height: 100,
                      width: 100,
                      color: GColors.primary,
                    ),
                    SizedBox(height: 15),
                    Text("Kontrol")
                  ],
                  ),
                ),
              ),

              SizedBox(height: 16),

            ],
          ),
        ),
      ),
    );
  }
}
