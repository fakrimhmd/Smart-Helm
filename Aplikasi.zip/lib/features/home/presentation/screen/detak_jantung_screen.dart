import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gpsapps/features/home/presentation/cubit/home_realtime_cubit.dart';
import 'package:gpsapps/features/home/presentation/cubit/home_realtime_cubit.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/routes/constants.dart';
import '../../../../core/routes/routes.dart';

class DetakJantungScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _DetakJantungScreenState();

}

class _DetakJantungScreenState extends State<DetakJantungScreen> {

  @override
  void initState() {
    context.read<HomeRealtimeCubit>().fetchMonitoringRealtime();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        AppRouter.router.go(Routes.homeScreenRootNamedPage);
      },
      child: Scaffold(
        backgroundColor: GColors.secondary,
        appBar: AppBar(title: Text("Detak Jantung",
          style: TextStyle(color: GColors.white),
        ),
          leading: IconButton(
            onPressed: () {
              AppRouter.router.go(Routes.homeScreenRootNamedPage);
            },
            icon: Icon(Icons.arrow_back), color: GColors.white,),
          centerTitle: true,
          backgroundColor: GColors.primary,
        ),

        // Detak Jantung Anda Sekarang
        body: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Image.asset('assets/images/heart_vector.png',
                height: 270,
              ),
              SizedBox(height: 15),

              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
                color: GColors.white),
                child: Text("Detak Jantung Anda Sekarang",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 20,
                    color: GColors.black,
                    fontWeight: FontWeight.w600
                ),
                ),
              ),

              SizedBox(height: 20),

              BlocBuilder<HomeRealtimeCubit, HomeRealtimeState>(
                builder: (context, state) {
                  if (state is MonitoringRealtimeSuccess){
                    final monitorData = state.monitoringReal;
                    final int detakJantungValue = monitorData['detak-jantung']?.first.detakJantung ?? 0;
                    return Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(40),
                      decoration: BoxDecoration(
                        color: Colors.white, // Background color
                        border: Border.all(
                          color: Colors.green, // Border color
                          width: 15.0, // Border width
                        ),
                        shape: BoxShape.circle, // Circular shape
                      ),
                      child: Column(
                        children: [
                          Text(detakJantungValue.toString(),
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 70,
                            ),
                          ),
                          Text("BPM",
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 20,
                            ),
                          )
                        ],
                      ),
                    );
                  }
                  else if (state is HomeRealtimeLoading){
                    return Center(child: CircularProgressIndicator(),);
                  }
                  else if (state is HomeRealtimeFailed) {
                    return Center(child: Text("Error ${state.error}"),);
                  }

                  else {
                    return Container();
                  }

                },
              ),

            ],
          ),
        ),
      ),
    );
  }
}