import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gpsapps/core/constants/colors.dart';
import 'package:gpsapps/core/routes/constants.dart';
import 'package:gpsapps/core/routes/routes.dart';
import 'package:gpsapps/core/widgets/custom_dialog.dart';
import 'package:gpsapps/features/home/presentation/widgets/custom_button.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:provider/provider.dart';

import '../cubit/home_realtime_cubit.dart';
import '../provider/home_realtime_bool.dart';

class LocationScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _LocationScreenState();

}

class _LocationScreenState extends State<LocationScreen>{
  @override
  Widget build(BuildContext context) {
    double latitude = 0.0;
    double longitude = 0.0;
    bool isMaps = false;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        AppRouter.router.go(Routes.homeScreenRootNamedPage);
      },
      child: Scaffold(
        backgroundColor: GColors.secondary,
        appBar: AppBar(title: Text("Lokasi",
        style: TextStyle(color: GColors.white),
        ),
        leading: IconButton(
          onPressed: () {
            AppRouter.router.go(Routes.homeScreenRootNamedPage);
          },
          icon: Icon(Icons.arrow_back),color: GColors.white,),
        centerTitle: true,
        backgroundColor: GColors.primary,
        ),
        body: Padding(
          padding: const EdgeInsets.all(25.0),
          child: Column(
            children: [
            Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
              color: GColors.white),
              padding: EdgeInsets.all(16),
                child: Image.asset('assets/images/maps_icon.png')),
            SizedBox(height: 30),
            BlocBuilder<HomeRealtimeCubit, HomeRealtimeState>(
              builder: (context, state) {
                if (state is HomeRealtimeLoading) {
                  return Align(
                      alignment: Alignment.center,
                      child: CircularProgressIndicator());
                } else {
                  return CustomButton(
                      title: "Dapatkan Data",
                      onPressed:() {
                        Provider.of<HomeRealtimeProvider>(context, listen: false)
                            .toggleIsMaps(true);
                        context.read<HomeRealtimeCubit>().fetchLocationRealtime();
                      });

                }

              },
            ),
            SizedBox(height: 30),
            BlocBuilder<HomeRealtimeCubit, HomeRealtimeState>(
              builder: (context, state) {
                if (state is LocationRealtimeSuccess) {
                  for (var healthRealModel in state.homeReal) {
                    latitude = healthRealModel.latitude;
                    longitude = healthRealModel.longitude;
                    break; // Exit the loop after the first assignment
                  }
                  return Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
                    color: GColors.white),

                    // height: 60,
                    padding: EdgeInsets.all(32),
                    alignment: Alignment.centerLeft,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text("Latitude: $latitude",
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 17

                        ),),
                        SizedBox(height: 5),
                        Text("Longitude: $longitude")
                      ],
                    ),
                  );
                } else if (state is HomeRealtimeFailed) {
                  String error = state.error;
                  Center(child: Text(error));
                } /*else if (state is HomeRealtimeLoading) {
                  return Center(child: CircularProgressIndicator());
                }*/
                return Container(
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
                      color: GColors.white),

                  // height: 60,
                  padding: EdgeInsets.all(32),
                  alignment: Alignment.centerLeft,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Latitude: "),
                      SizedBox(height: 5),
                      Text("Longitude: ")
                    ],
                  ),
                );
              },
            ),
            SizedBox(height: 30),


                Consumer<HomeRealtimeProvider>(
                  builder: (context, provider, child) {
                    return CustomButton(
                        title: "Buka Maps",
                        onPressed: () async {
                          if (provider.isMaps){
                            openMapsSheet(context, latitude, longitude);
                          }
                          else {
                            CustomShowDialog.showCustomDialog(
                                context,
                                title: "Info",
                                message: "Tekan Dapatkan Data terlebih dahulu",
                                isCancel: false);
                          }
                        });
                    return ElevatedButton(onPressed: () async {
                      print(provider.isMaps);
                      if (provider.isMaps){
                        openMapsSheet(context, latitude, longitude);
                      }
                      //DO NOTHING
                    }, child: Text("Maps"));
                  },
                )

          ],),
        ),
      ),
    );
  }
  void openMapsSheet(BuildContext context, double latitude, double longitude) async {
    try {
      final coords = Coords(latitude, longitude);
      final title = "$latitude $longitude";
      final availableMaps = await MapLauncher.installedMaps;

      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return SafeArea(
            child: SingleChildScrollView(
              child: Container(
                color: GColors.white,
                child: Wrap(
                  children: <Widget>[
                    for (var map in availableMaps)
                      ListTile(
                        onTap: () => map.showMarker(
                          coords: coords,
                          title: title,
                        ),
                        title: Text(map.mapName),
                        leading: SvgPicture.asset(
                          map.icon,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    } catch (e) {
      print(e);
    }
  }
}