import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gpsapps/features/home/presentation/cubit/home_realtime_cubit.dart';

import '../../../../core/constants/colors.dart';
import '../../../../core/routes/constants.dart';
import '../../../../core/routes/routes.dart';

class KontrolScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _KontrolScreenState();
}

class _KontrolScreenState extends State<KontrolScreen> {

  @override
  void initState() {
    super.initState();
    context.read<HomeRealtimeCubit>().fetchControlRealtime();
  }

  // late bool isOn = false;



  @override
  Widget build(BuildContext context) {
    return PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          AppRouter.router.go(Routes.homeScreenRootNamedPage);
        },
        child: Scaffold(
          backgroundColor: GColors.secondary,
          appBar: AppBar(title: Text("Kontrol",
            style: TextStyle(color: GColors.white),
          ),
            leading: IconButton(
              onPressed: () {
                AppRouter.router.go(Routes.homeScreenRootNamedPage);
              },
              icon: Icon(Icons.arrow_back), color: GColors.white,),
            centerTitle: true,
            backgroundColor: GColors.primary,
          ),
          body: Padding(padding: EdgeInsets.all(25),
            child: Column(
              children: [
                SizedBox(height: 50),
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      color: GColors.white
                  ),
                  child: Image.asset('assets/images/switch_icon.png'),
                  height: 200,
                  width: 200,),
                SizedBox(height: 30),

                BlocBuilder<HomeRealtimeCubit, HomeRealtimeState>(
                  builder: (context, state) {
                    if (state is ControlRealtimeSuccess){
                      final controlData = state.controlReal;
                      final sistemState = controlData['sistem-state']?.first.isOn ?? false;
                      return Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            color: GColors.white),
                        padding: EdgeInsets.all(15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Sistem Kontrol",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'Poppins'
                              ),),
                            Switch(value: sistemState,
                                // activeColor: GColors.primary,
                                inactiveTrackColor: GColors.secondary,
                                activeColor: GColors.white,
                                activeTrackColor: GColors.primary
                                ,
                                onChanged: (bool newValue) {
                                  // setState(() {
                                  //   isOn = !isOn;
                                  // });
                                  context.read<HomeRealtimeCubit>().updateSistemState(newValue);
                                  // context.read<HomeRealtimeCubit>().fetchControlRealtime();
                                }),
                          ],),
                      );
                    }

                    else if (state is HomeRealtimeLoading) {
                      return Center(child: CircularProgressIndicator(),);
                    }

                    else if (state is HomeRealtimeFailed){
                      return Center(child: Text("Get Data Error"),);
                    }

                    return Container();
                  },
                )
              ],),),
        )
    );
  }
}