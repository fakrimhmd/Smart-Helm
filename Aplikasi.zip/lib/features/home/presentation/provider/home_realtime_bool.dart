import 'package:flutter/cupertino.dart';

class HomeRealtimeProvider with ChangeNotifier {
  bool _isMaps = false;

  bool get isMaps => _isMaps;

  void toggleIsMaps(bool value) {
    _isMaps = value;
    notifyListeners();
  }
}