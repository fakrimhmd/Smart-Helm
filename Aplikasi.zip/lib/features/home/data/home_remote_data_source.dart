import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:gpsapps/features/home/model/home_model.dart';
import 'package:intl/intl.dart';



class HomeService {
  final DatabaseReference _homeRealRef = FirebaseDatabase.instance.ref(); //.child('${FirebaseAuth.instance.currentUser!.uid}');
  final _firebaseMessaging = FirebaseMessaging.instance;
  CollectionReference _healthReference = FirebaseFirestore.instance.collection('userFCM');


  Future<List<HomeModel>> fetchRealtime() async {
    try {
      final DataSnapshot latitudeSnapshot  = await _homeRealRef.child('nilai-latitude').get();
      final DataSnapshot longitudeSnapshot  = await _homeRealRef.child('nilai-longitude').get();

      if (latitudeSnapshot.exists && longitudeSnapshot.exists) {
        final double latitude = double.parse(latitudeSnapshot.value.toString());
        final double longitude = double.parse(longitudeSnapshot.value.toString());
        final List<HomeModel> homeDataList = [
          HomeModel(
              latitude:  latitude,// Add 'kg' as a unit
              longitude: longitude
          )
        ];
        print(latitude);
        return homeDataList;
      } else {
        return []; // Return an empty list if any data is missing
      }
    } catch (error) {
      print('Error fetching data: $error');
      return []; // Return an empty list in case of an error
    }
  }

  Stream<List<MonitoringModel>> fetchMonitoringRealtime() {
    return _homeRealRef.onValue.map((event) {
      final detakJantung = event.snapshot.child('detak-jantung');

      if (detakJantung.exists){
        final int detakJantungValue = int.parse(detakJantung.value.toString());
        return [
        MonitoringModel(
            detakJantung: detakJantungValue
        ),
      ];
      } else {
        return [];
      }
    });
  }

  Stream<List<ControlModel>> fetchControlRealtime() {
    return _homeRealRef.onValue.map((event) {
      final sistemState = event.snapshot.child('sistem-state');
      if (sistemState.exists){
        final bool sistemStateValue = bool.parse(sistemState.value.toString());
        return [
          ControlModel(
              isOn: sistemStateValue
          ),
        ];
      } else {
        return [];
      }
    });
  }

  Future<void> updateRealtime({required Map<String, dynamic> data}) async {
    await _homeRealRef.update(data);
  }

  Future<void> addDataCloudFirestore({
    required String? token,
    required String? deviceType,
  }) async {
    try {
      // Check for existing document with the same token and deviceType
      QuerySnapshot querySnapshot = await _healthReference
          .where('userToken', isEqualTo: token)
          // .where('deviceType', isEqualTo: deviceType)
          .get();

      if (querySnapshot.docs.isEmpty) {
        // No duplicates found, proceed to add the new data
        await _healthReference.add({
          'userToken': token,
          'deviceType': deviceType,
        });
      } else {
        print('Document with the same token already exists.');
      }
    } catch (e) {
      throw e;
    }
  }
  // Future<void> addDataCloudFirestore({
  //   required String? token,
  //   required String? deviceType,
  //   // required double height,
  //   // required double headCircumference,
  //   // DateTime? dateTime, // Use DateTime? to allow nullable values
  // }) async {
  //   try {
  //     await _healthReference
  //         .add({
  //       'userToken': token,
  //       'deviceType': deviceType,
  //       // 'height': height,
  //       // 'headCircumference': headCircumference,
  //       // 'dateTime': dateTime,
  //       // 'dateTime': dateTime ?? DateTime.now(),
  //     });
  //   } catch (e) {
  //     throw e;
  //   }
  // }




}