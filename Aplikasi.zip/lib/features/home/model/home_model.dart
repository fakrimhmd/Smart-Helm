import 'package:equatable/equatable.dart';

class HomeModel extends Equatable {
  final double latitude;
  final double longitude;

  HomeModel({
    required this.latitude,
    required this.longitude,
  });


  @override
  List<Object?> get props => [latitude,longitude];
}

class ControlModel extends Equatable {
  final bool isOn;
  // final double longitude;

  ControlModel({
    required this.isOn,
    // required this.longitude,
  });


  @override
  List<Object?> get props => [isOn];
}

class MonitoringModel extends Equatable {
  final int detakJantung;
  // final double longitude;

  MonitoringModel({
    required this.detakJantung,
    // required this.longitude,
  });


  @override
  List<Object?> get props => [detakJantung];
}