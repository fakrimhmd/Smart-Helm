package com.example.gpsapps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
